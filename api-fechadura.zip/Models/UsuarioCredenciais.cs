namespace api_fechadura.Models
{
    public class UsuarioCredenciais
    {
 
        public int nif { get; set; }
        public string senha { get; set; }
        
    }
}